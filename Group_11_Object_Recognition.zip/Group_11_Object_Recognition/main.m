im=imread('vehicle1.jpg');
k=im;
im=imresize(im,[256 256]);
figure,
subplot(2,2,1);
imshow(im),title('Original image');
im=rgb2gray(im);
k=imresize(k,[256 256]);

se = strel('disk', 1, 0); 

B=im;
C=double(im);

B=edge(C,'Canny');
subplot(2,2,2)
imshow(B); title('Canny edge detection');

%c = im2bw(B);
c=imdilate(B,se);

subplot(2,2,3)
imshow(c);title('Thinkening edges by dilation');
B=c;
S=B;
se1=strel('disk',2);
B=imopen(B,se);
 [m,n]=size(S);
%figure,imshow(S),title('image')
for i=1:m
    for j=1:n
        if(S(i,j)>0)
            k(i,j,1)=0;
            k(i,j,2)=0;
            k(i,j,3)=0;
        end
    end
end
subplot(2,2,4)
imshow(k);title('Object detection Output');
m=regionprops(B,'BoundingBox');
    for k = 1 : length(m)
    thisBB = m(k).BoundingBox;
    rectangle('Position', [thisBB(1),thisBB(2),thisBB(3),thisBB(4)],...
    'EdgeColor','r','LineWidth',2 )
    end
